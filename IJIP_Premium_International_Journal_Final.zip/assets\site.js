/* ==========================================================================
   IJPC — International Journal of Psychological Community
   Interactive Platform Scripts (Zero external JS dependencies)
   ========================================================================== */
(function () {
  'use strict';

  const ROOT = document.documentElement.dataset.root || './';
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Toast Notification ---------- */
  let toastTimer = null;
  function showToast(msg) {
    let el = document.querySelector('.toast');
    if (!el) {
      el = document.createElement('div');
      el.className = 'toast';
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('is-visible'), 2800);
  }

  /* ---------- Reading Progress & Sticky Header ---------- */
  const progressBar = document.querySelector('.reading-progress');
  const siteHeader = document.querySelector('.site-header');

  function onScroll() {
    const y = window.scrollY || window.pageYOffset;
    if (siteHeader) {
      siteHeader.classList.toggle('is-scrolled', y > 18);
    }
    if (progressBar) {
      const docHeight = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const pct = Math.min(100, Math.max(0, (y / docHeight) * 100));
      progressBar.style.width = pct.toFixed(2) + '%';
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Desktop Dropdown Navigation ---------- */
  const navDropdownItems = document.querySelectorAll('.nav-item.has-dropdown');
  navDropdownItems.forEach((item) => {
    const trigger = item.querySelector('.nav-trigger');
    if (!trigger) return;
    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      const willOpen = !item.classList.contains('is-open');
      navDropdownItems.forEach((other) => {
        other.classList.remove('is-open');
        other.querySelector('.nav-trigger')?.setAttribute('aria-expanded', 'false');
      });
      if (willOpen) {
        item.classList.add('is-open');
        trigger.setAttribute('aria-expanded', 'true');
      }
    });
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-item.has-dropdown')) {
      navDropdownItems.forEach((item) => {
        item.classList.remove('is-open');
        item.querySelector('.nav-trigger')?.setAttribute('aria-expanded', 'false');
      });
    }
  });

  /* ---------- Mobile Drawer & Accordions ---------- */
  const drawer = document.querySelector('.mobile-drawer');
  const backdrop = document.querySelector('.mobile-drawer-backdrop');
  const openDrawerBtn = document.querySelector('[data-drawer-open]');

  function setDrawer(open) {
    if (!drawer || !backdrop) return;
    drawer.classList.toggle('is-open', open);
    drawer.setAttribute('aria-hidden', String(!open));
    backdrop.classList.toggle('is-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
    openDrawerBtn?.setAttribute('aria-expanded', String(open));
    if (open) {
      drawer.querySelector('[data-drawer-close], a')?.focus();
    }
  }

  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-drawer-open]')) {
      e.preventDefault();
      setDrawer(true);
    } else if (e.target.closest('[data-drawer-close]') || e.target === backdrop) {
      e.preventDefault();
      setDrawer(false);
    }
  });

  document.querySelectorAll('.mobile-nav-acc-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const sub = btn.nextElementSibling;
      if (!sub) return;
      const open = !sub.classList.contains('is-open');
      sub.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
      const icon = btn.querySelector('.acc-plus');
      if (icon) icon.textContent = open ? '−' : '+';
    });
  });

  /* ---------- Global Site Search Modal ---------- */
  const SITE_INDEX = [
    { type: 'Research Paper', title: 'The Rise of Collective Digital Surveillance: Moral Policing, Parasocial Entitlement, and Public Figure Mental Health', meta: 'Amirdha. G · Vol. 1 Issue 1 · pp. 1–5 · ijpc2026001', url: 'articles/article-01/' },
    { type: 'Research Paper', title: 'Relationship Between Procrastination, Self-Esteem and Self-Efficacy Among Young Adults', meta: 'V. S. Devisri et al. · Vol. 1 Issue 1 · pp. 6–12 · ijpc2026002', url: 'articles/article-02/' },
    { type: 'Research Paper', title: 'The Study On Academic Burnout Among Undergraduate Students', meta: 'Dennis.E, Rishikesh.S · Vol. 1 Issue 1 · pp. 13–19 · ijpc2026003', url: 'articles/article-03/' },
    { type: 'Research Paper', title: 'Relationship Between Cognitive Style and Leadership Preference Among College Students in Selected Institutions of Coimbatore', meta: 'Dhanraj, S. & G. K. Sellakumar · Vol. 1 Issue 1 · pp. 20–26 · ijpc2026004', url: 'articles/article-04/' },
    { type: 'Research Paper', title: 'The Influence of Peer Pressure Susceptibility on Fear of Missing Out (FOMO) Among Young Adults in Digital Social Environments', meta: 'G. Tarika Latha & Afshan T. · Vol. 1 Issue 1 · pp. 27–34 · ijpc2026005', url: 'articles/article-05/' },
    { type: 'Research Paper', title: 'The Dynamics of Female Representation in Action Sequences of Contemporary Hindi Cinema', meta: 'Srilakshmi, Vignesh G, Dr. B. Geetha · Vol. 1 Issue 1 · pp. 35–42 · ijpc2026006', url: 'articles/article-06/' },
    { type: 'Research Paper', title: 'Perceived Overparenting and Health-Related Quality of Life Among Emerging Adults: A Cross-Sectional Study', meta: 'K. Menaashe Pooja & B. Damodaran · Vol. 1 Issue 1 · pp. 43–53 · ijpc2026007', url: 'articles/article-07/' },
    { type: 'Research Paper', title: 'Rhythm and Regulation: A Tech-Driven Approach to Stuttering in Students Using an Integrative Review', meta: 'Meera M. & M. Akilandeswari, Ph.D. · Vol. 1 Issue 1 · pp. 54–66 · ijpc2026008', url: 'articles/article-08/' },
    { type: 'Research Paper', title: 'Trauma, Loss, and Recovery: A Case Study of Psychological Counselling in an HIV-Orphaned Adolescent Girl with Complex Trauma and Anxiety', meta: 'Annie Christabel, Rajkumar R., Vivek Sugadev · Vol. 1 Issue 1 · pp. 67–74 · ijpc2026009', url: 'articles/article-09/' },
    { type: 'Research Paper', title: 'Emotional Expressivity and Emotional Regulation Among Bharatanatyam Dancers and Non-Dancers', meta: 'Sija V. & G. K. Sellakumar · Vol. 1 Issue 1 · pp. 75–82 · ijpc2026010', url: 'articles/article-10/' },
    { type: 'Research Paper', title: 'Examining the Need for Sexuality Education in India: A Review of Government Policies, Laws, and Programmes', meta: 'Thulasi R · Vol. 1 Issue 1 · pp. 83–91 · ijpc2026011', url: 'articles/article-11/' },
    { type: 'Research Paper', title: 'Assessment and Management of Personality Traits for Addiction', meta: 'B Anita · Vol. 1 Issue 1 · pp. 92–102 · ijpc2026012', url: 'articles/article-12/' },
    { type: 'Journal Issue', title: 'Volume 1, Issue 1 – September 2026 (Complete Inaugural Volume)', meta: '12 Peer-Reviewed Articles · e-ISSN 2839-5638', url: 'volumes/volume-1-issue-1/' },
    { type: 'Journal Page', title: 'About the Journal', meta: 'Scope, open-access mission, and publication details', url: 'about-the-journal/' },
    { type: 'Journal Page', title: 'About the Publisher — Tamil Nadu Psychology Association (TNPA)', meta: 'Registration No. 121 / 2014 · Research collaboration with IIPRT', url: 'about-the-publisher/' },
    { type: 'Journal Page', title: 'Editorial Board & Reviewers', meta: 'Editor-in-Chief, Co-Editors, Editorial Board, Reviewer Board, Advisory Board', url: 'editorial-board/' },
    { type: 'Journal Page', title: 'Call for Paper', meta: 'Quarterly submission schedule & 19 accepted research paper types', url: 'call-for-paper/' },
    { type: 'Journal Page', title: 'Author Guidelines & Fee Structure', meta: 'Plagiarism rules, fee payment, PNB bank details & UPI QR', url: 'author-guidelines/' },
    { type: 'Journal Page', title: 'Submission Guidelines — APA 7th Edition Modules', meta: 'Formatting templates & research paper samples', url: 'submission-guidelines/' },
    { type: 'Journal Page', title: 'Submit Your Manuscript (Registration Form)', meta: 'Online manuscript registration and submission portal', url: 'common-signup/' },
    { type: 'Journal Page', title: 'Book Publication Services (ISBN)', meta: 'Edited volumes, book chapters, conference monographs & thesis conversion', url: 'book-publication/' },
    { type: 'Journal Page', title: 'Special Publication & Conference Proceedings', meta: 'ISSN Special Issues & ISBN Conference Proceedings Books', url: 'special-publication/' },
    { type: 'Journal Page', title: 'Published Journals & Archive', meta: 'Browse Volume 1, Issue 1 and search all published articles', url: 'journal-publication/' },
    { type: 'Journal Page', title: 'Previous Issues Archive', meta: 'Historical issues, cover pages, index records & article archive', url: 'previous-issue/' },
    { type: 'Journal Page', title: 'Blog For Writer', meta: 'Free psychology article contributions & APA writing guidelines', url: 'blog-for-writer/' },
    { type: 'Journal Page', title: 'Disclaimer & Submission Policy', meta: 'Originality, authorship, copyright transfer & plagiarism policy', url: 'disclaimer/' },
    { type: 'Journal Page', title: 'Contact Us', meta: 'Registered address, Editorial Office, Sri Ponni Printers & inquiry form', url: 'contact-us/' },
    { type: 'APA Resource', title: 'Combined Submission Form', meta: 'Covering letter, author declaration, copyright & plagiarism declaration', url: 'resources/combined-submission-form/' },
    { type: 'APA Resource', title: 'APA Manuscript Formatting Guide', meta: 'Accepted fonts, line spacing, margins & paragraph alignment', url: 'resources/apa-manuscript-formatting/' },
    { type: 'APA Resource', title: 'APA Publication Manual 7th Edition', meta: 'Official APA 7th Edition reference link', url: 'resources/apa-publication-mannual-7th-edition/' },
    { type: 'APA Resource', title: 'Student Full Paper Module (APA 7th)', meta: 'Annotated student manuscript visual guide', url: 'resources/apa-formet-for-student-articicle/' },
    { type: 'APA Resource', title: 'Literature Review Professional Paper Sample', meta: 'APA 7th professional template', url: 'resources/1-literature-review-professional-paper/' },
    { type: 'APA Resource', title: 'Qualitative Professional Paper Sample', meta: 'APA 7th professional template', url: 'resources/2-qualitative-professional-paper/' },
    { type: 'APA Resource', title: 'Quantitative Professional Paper Sample', meta: 'APA 7th professional template', url: 'resources/3-quantitative-professional-paper/' },
    { type: 'APA Resource', title: 'Mixed Methods Professional Paper Sample', meta: 'APA 7th professional template', url: 'resources/4-mixed-methods-professional-paper/' },
    { type: 'APA Resource', title: 'Case Study Method Guide', meta: 'APA 7th methodology template', url: 'resources/case-study-method/' }
  ];

  const searchModal = document.querySelector('.search-modal');
  const searchInput = document.querySelector('#global-search-input');
  const searchResults = document.querySelector('#global-search-results');

  function renderSearchResults(query) {
    if (!searchResults) return;
    const q = (query || '').trim().toLowerCase();
    const matches = q
      ? SITE_INDEX.filter((item) =>
          (item.title + ' ' + item.meta + ' ' + item.type).toLowerCase().includes(q)
        )
      : SITE_INDEX.slice(0, 8);

    if (!matches.length) {
      searchResults.innerHTML =
        '<p style="padding:1rem;color:var(--ink-muted);text-align:center;">No matching articles, guidelines, or resources found for "' +
        q.replace(/[<>&"]/g, '') +
        '".</p>';
      return;
    }

    searchResults.innerHTML = matches
      .slice(0, 14)
      .map(
        (item) =>
          '<a class="search-result-item" href="' +
          ROOT +
          item.url +
          '">' +
          '<div class="search-result-item__type">' +
          item.type +
          '</div>' +
          '<div class="search-result-item__title">' +
          item.title +
          '</div>' +
          '<div class="search-result-item__meta">' +
          item.meta +
          '</div>' +
          '</a>'
      )
      .join('');
  }

  function setSearchModal(open) {
    if (!searchModal) return;
    if (open) setDrawer(false);
    searchModal.classList.toggle('is-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) {
      renderSearchResults(searchInput?.value || '');
      setTimeout(() => searchInput?.focus(), 60);
    }
  }

  document.querySelectorAll('[data-search-open]').forEach((btn) =>
    btn.addEventListener('click', () => setSearchModal(true))
  );
  document.querySelectorAll('[data-search-close]').forEach((btn) =>
    btn.addEventListener('click', () => setSearchModal(false))
  );
  searchModal?.addEventListener('click', (e) => {
    if (e.target === searchModal) setSearchModal(false);
  });
  searchInput?.addEventListener('input', (e) => renderSearchResults(e.target.value));

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      setSearchModal(true);
    }
    if (e.key === 'Escape') {
      setSearchModal(false);
      setDrawer(false);
      navDropdownItems.forEach((item) => {
        item.classList.remove('is-open');
        item.querySelector('.nav-trigger')?.setAttribute('aria-expanded', 'false');
      });
    }
  });

  /* ---------- Homepage 4-Slide Cinematic Hero Slider ---------- */
  const heroSlider = document.querySelector('[data-hero-slider]');
  if (heroSlider) {
    const slides = Array.from(heroSlider.querySelectorAll('.hero-slide'));
    const dots = Array.from(heroSlider.querySelectorAll('.hero-dot'));
    const prevBtn = heroSlider.querySelector('[data-hero-prev]');
    const nextBtn = heroSlider.querySelector('[data-hero-next]');
    const pauseBtn = heroSlider.querySelector('[data-hero-pause]');
    let index = 0;
    let timer = null;
    let userPaused = prefersReduced;
    let pointerStartX = 0;

    function goTo(newIdx) {
      index = (newIdx + slides.length) % slides.length;
      slides.forEach((s, i) => {
        const active = i === index;
        s.classList.toggle('is-active', active);
        s.setAttribute('aria-hidden', String(!active));
      });
      dots.forEach((d, i) => {
        const active = i === index;
        d.setAttribute('aria-selected', String(active));
        // Restart progress bar animation cleanly
        if (active) {
          d.style.animation = 'none';
          void d.offsetWidth;
          d.style.animation = '';
        }
      });
    }

    function startAuto() {
      stopAuto();
      if (userPaused) return;
      heroSlider.classList.remove('is-paused');
      timer = setInterval(() => goTo(index + 1), 5500);
    }

    function stopAuto() {
      if (timer) clearInterval(timer);
      timer = null;
      heroSlider.classList.add('is-paused');
    }

    prevBtn?.addEventListener('click', () => {
      goTo(index - 1);
      if (!userPaused) startAuto();
    });

    nextBtn?.addEventListener('click', () => {
      goTo(index + 1);
      if (!userPaused) startAuto();
    });

    dots.forEach((dot, i) => {
      dot.addEventListener('click', () => {
        goTo(i);
        if (!userPaused) startAuto();
      });
    });

    pauseBtn?.addEventListener('click', () => {
      userPaused = !userPaused;
      pauseBtn.setAttribute('aria-pressed', String(userPaused));
      pauseBtn.setAttribute('aria-label', userPaused ? 'Resume slideshow' : 'Pause slideshow');
      pauseBtn.innerHTML = userPaused
        ? '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><polygon points="6,4 20,12 6,20"/></svg>'
        : '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
      if (userPaused) stopAuto();
      else startAuto();
    });

    heroSlider.addEventListener('mouseenter', stopAuto);
    heroSlider.addEventListener('mouseleave', () => { if (!userPaused) startAuto(); });
    heroSlider.addEventListener('focusin', stopAuto);
    heroSlider.addEventListener('focusout', () => { if (!userPaused) startAuto(); });

    heroSlider.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') { goTo(index - 1); if (!userPaused) startAuto(); }
      if (e.key === 'ArrowRight') { goTo(index + 1); if (!userPaused) startAuto(); }
    });

    heroSlider.addEventListener('touchstart', (e) => {
      pointerStartX = e.changedTouches[0].clientX;
    }, { passive: true });

    heroSlider.addEventListener('touchend', (e) => {
      const dx = e.changedTouches[0].clientX - pointerStartX;
      if (Math.abs(dx) > 45) {
        goTo(dx > 0 ? index - 1 : index + 1);
        if (!userPaused) startAuto();
      }
    }, { passive: true });

    goTo(0);
    if (!userPaused) startAuto();
  }

  /* ---------- Author & Researcher Horizontal Carousel ---------- */
  document.querySelectorAll('[data-researcher-carousel]').forEach((carousel) => {
    const track = carousel.querySelector('.researcher-carousel__track');
    const cards = Array.from(carousel.querySelectorAll('.researcher-card'));
    const prevBtn = carousel.querySelector('[data-carousel-prev]');
    const nextBtn = carousel.querySelector('[data-carousel-next]');
    if (!track || !cards.length) return;

    let pos = 0;
    let autoTimer = null;
    let touchStartX = 0;

    function visibleCount() {
      const w = window.innerWidth;
      if (w <= 520) return 1;
      if (w <= 960) return 2;
      if (w <= 1120) return 3;
      return 4;
    }

    function maxPos() {
      return Math.max(0, cards.length - visibleCount());
    }

    function updatePosition(nextPos) {
      const max = maxPos();
      if (nextPos > max) pos = 0;
      else if (nextPos < 0) pos = max;
      else pos = nextPos;

      const offset = cards[pos].offsetLeft - cards[0].offsetLeft;
      track.style.transform = `translate3d(-${offset}px, 0, 0)`;
    }

    function startSlide() {
      stopSlide();
      if (prefersReduced) return;
      autoTimer = setInterval(() => updatePosition(pos + 1), 3800);
    }

    function stopSlide() {
      if (autoTimer) clearInterval(autoTimer);
      autoTimer = null;
    }

    prevBtn?.addEventListener('click', () => { updatePosition(pos - 1); startSlide(); });
    nextBtn?.addEventListener('click', () => { updatePosition(pos + 1); startSlide(); });

    carousel.addEventListener('mouseenter', stopSlide);
    carousel.addEventListener('mouseleave', startSlide);
    carousel.addEventListener('focusin', stopSlide);
    carousel.addEventListener('focusout', startSlide);

    carousel.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].clientX;
      stopSlide();
    }, { passive: true });

    carousel.addEventListener('touchend', (e) => {
      const dx = e.changedTouches[0].clientX - touchStartX;
      if (Math.abs(dx) > 40) updatePosition(dx > 0 ? pos - 1 : pos + 1);
      startSlide();
    }, { passive: true });

    window.addEventListener('resize', () => updatePosition(pos));
    updatePosition(0);
    startSlide();
  });

  /* ---------- Archive Filtering, Search & Grid/List View ---------- */
  const archiveSearch = document.querySelector('#archive-search');
  const archiveCards = Array.from(document.querySelectorAll('[data-article-card]'));
  const archiveGrid = document.querySelector('[data-articles-grid]');
  const filterPills = Array.from(document.querySelectorAll('[data-topic-filter]'));
  const countLabel = document.querySelector('[data-archive-count]');
  let activeTopic = 'all';

  function applyArchiveFilters() {
    if (!archiveCards.length) return;
    const q = (archiveSearch?.value || '').trim().toLowerCase();
    let visible = 0;
    archiveCards.forEach((card) => {
      const text = (card.dataset.search || '').toLowerCase();
      const topic = (card.dataset.topic || '').toLowerCase();
      const matchQuery = !q || text.includes(q);
      const matchTopic = activeTopic === 'all' || topic.includes(activeTopic);
      const show = matchQuery && matchTopic;
      card.hidden = !show;
      if (show) visible++;
    });
    if (countLabel) {
      countLabel.textContent = `Showing ${visible} of ${archiveCards.length} published articles`;
    }
  }

  if (archiveSearch) {
    const params = new URLSearchParams(window.location.search);
    const initialQ = params.get('q');
    if (initialQ) {
      archiveSearch.value = initialQ;
    }
    archiveSearch.addEventListener('input', applyArchiveFilters);
  }

  filterPills.forEach((pill) => {
    pill.addEventListener('click', () => {
      activeTopic = (pill.dataset.topicFilter || 'all').toLowerCase();
      filterPills.forEach((p) => p.classList.toggle('is-active', p === pill));
      applyArchiveFilters();
    });
  });

  document.querySelectorAll('[data-view-mode]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const mode = btn.dataset.viewMode;
      document.querySelectorAll('[data-view-mode]').forEach((b) =>
        b.classList.toggle('is-active', b === btn)
      );
      archiveGrid?.classList.toggle('is-list', mode === 'list');
    });
  });

  applyArchiveFilters();

  /* ---------- Editorial Board Category Filter ---------- */
  const boardTabs = Array.from(document.querySelectorAll('[data-board-filter]'));
  const boardSections = Array.from(document.querySelectorAll('[data-board-group]'));
  boardTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.boardFilter;
      boardTabs.forEach((t) => t.classList.toggle('is-active', t === tab));
      boardSections.forEach((sec) => {
        const show = target === 'all' || sec.dataset.boardGroup === target;
        sec.hidden = !show;
        if (show) sec.classList.add('is-visible');
      });
    });
  });

  /* ---------- Copy to Clipboard Buttons ---------- */
  document.querySelectorAll('[data-copy-text]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const text = btn.dataset.copyText || '';
      const label = btn.dataset.copyLabel || 'Copied to clipboard';
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(text);
        } else {
          const ta = document.createElement('textarea');
          ta.value = text;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
        }
        showToast(label);
      } catch {
        showToast('Unable to copy automatically — please copy manually.');
      }
    });
  });

  /* ---------- Article Reader TOC Scrollspy ---------- */
  const tocLinks = Array.from(document.querySelectorAll('.toc-list a[href^="#"]'));
  if (tocLinks.length && 'IntersectionObserver' in window) {
    const sections = tocLinks
      .map((a) => document.querySelector(a.getAttribute('href')))
      .filter(Boolean);
    const spy = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = '#' + entry.target.id;
            tocLinks.forEach((a) => a.classList.toggle('is-active', a.getAttribute('href') === id));
          }
        });
      },
      { rootMargin: '-18% 0px -70% 0px', threshold: 0 }
    );
    sections.forEach((sec) => spy.observe(sec));
  }

  /* ---------- Scroll Reveal Animations ---------- */
  const reveals = Array.from(document.querySelectorAll('.reveal'));
  if (reveals.length) {
    if (prefersReduced || !('IntersectionObserver' in window)) {
      reveals.forEach((el) => el.classList.add('is-visible'));
    } else {
      const checkVisible = () => {
        const vh = window.innerHeight || 900;
        reveals.forEach((el) => {
          if (el.classList.contains('is-visible') || el.hidden) return;
          const rect = el.getBoundingClientRect();
          if (rect.top < vh + 120 && rect.bottom > -80) {
            el.classList.add('is-visible');
          }
        });
      };
      const revObs = new IntersectionObserver(
        (entries, obs) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              obs.unobserve(entry.target);
            }
          });
        },
        { rootMargin: '80px 0px 120px 0px', threshold: 0.01 }
      );
      reveals.forEach((el) => revObs.observe(el));
      window.addEventListener('scroll', checkVisible, { passive: true });
      checkVisible();
    }
  }

  /* ---------- Mobile Footer Collapsible Sections ---------- */
  document.querySelectorAll('.footer-col--collapsible .footer-col__title').forEach((title) => {
    title.addEventListener('click', () => {
      if (window.innerWidth > 720) return;
      const col = title.closest('.footer-col--collapsible');
      if (!col) return;
      const open = !col.classList.contains('is-open');
      col.classList.toggle('is-open', open);
      const btn = title.querySelector('.footer-col__toggle');
      if (btn) btn.setAttribute('aria-expanded', String(open));
    });
  });

  /* ---------- Progressive Enhancement for PHP Forms ---------- */
  document.querySelectorAll('form[data-enhanced-form]').forEach((form) => {
    form.addEventListener('submit', async (e) => {
      if (window.location.protocol === 'file:') {
        e.preventDefault();
        const status = form.querySelector('.form-status');
        if (status) {
          status.textContent =
            'This form submits to backend/submit.php when hosted on a PHP-enabled web server. For direct editorial assistance right now, please email editor@ijpc.in.';
          status.classList.add('is-visible', 'form-status--info');
        }
        showToast('PHP server required for live submission — see editor@ijpc.in');
        return;
      }
      // On HTTP/HTTPS, allow normal POST to backend/submit.php unless JS fetch is desired.
    });
  });
})();
